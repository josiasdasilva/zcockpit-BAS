sap.ui.define([
	"dma/zcockpit/test/unit/controller/View1.controller"
], function () {
	"use strict";
});